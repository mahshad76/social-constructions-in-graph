
public class Node{


    private DataItems dataItems;
    private Node nextNode;

    public void setNextNode(Node _nextNode){
        this.nextNode=_nextNode;
    }

    public Node getNextNode(){
        return nextNode;
    }

    public DataItems getDataItems(){
        return dataItems;
    }

    public void setDataItems(DataItems _dataItems){
        this.dataItems=_dataItems;
    }

}