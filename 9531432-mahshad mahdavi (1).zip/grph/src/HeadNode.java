
public class HeadNode{

// immutable class representing head node of linked list

    Node nextNode;

    public void setNextNode(Node _nextNode) {
        nextNode=_nextNode;
    }

    public Node getNextNode() {
        return nextNode;
    }

}