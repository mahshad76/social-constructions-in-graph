import java.io.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;


public class MatrixGraph {
    //public int m;
    public int n;
    public int mx=0;
    public int ls=0;
    public HashMap<Integer,String> stx;
    public int length;
    public HashMap<ArrayList<Integer>,Integer> Adjust1;
    public LinkedList Adjust2;
    Node first[];
    HashMap<Integer,HashMap<ArrayList<Integer>,Double>> TempScore;
    public HashMap<Integer,HashMap<ArrayList<Integer>,Double>> Score;
    public int N1=0;
    public int N2=0;
    PrintWriter log=null;
    ArrayList<Integer> temp;
    ArrayList<Integer> temp1;
    public MatrixGraph(){
        Score=new HashMap<Integer,HashMap<ArrayList<Integer>,Double>>();
        stx=new HashMap<Integer,String>();
        Adjust2=new LinkedList();
    }
    public HashMap<ArrayList<Integer>,Integer> CreateMatrix(String filename){
        mx=1;ls=0;
        HashMap<ArrayList<Integer>,Integer> Adjust1_temp =new HashMap<ArrayList<Integer>,Integer>();
        ArrayList<Integer> temp=new ArrayList<Integer>();
        try {
            File file = new File(filename);
            FileReader fileReader = new FileReader(file);
            FileReader fileReader1 = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            BufferedReader bufferedReader1 = new BufferedReader(fileReader1);
            StringBuffer stringBuffer = new StringBuffer();
            StringBuffer stringBuffer1 = new StringBuffer();
            String line;
            String line1;
            while ((line1 = bufferedReader1.readLine()) != null) {
                String m[] = line1.split(",");
                if (!temp.contains(Integer.parseInt(m[0])))
                    temp.add(Integer.parseInt(m[0]));
                if (!temp.contains(Integer.parseInt(m[1])))
                    temp.add(Integer.parseInt(m[1]));
            }
            n=temp.size();

            while ((line = bufferedReader.readLine()) != null) {
                String m[] = line.split(",");
                ArrayList<Integer> e1=new ArrayList<Integer>();
                e1.add(0,Integer.parseInt(m[0]));
                e1.add(1,Integer.parseInt(m[1]));
                ArrayList<Integer> e2=new ArrayList<Integer>();
                e2.add(0,Integer.parseInt(m[1]));
                e2.add(1, Integer.parseInt(m[0]));
               if(!Adjust1_temp.containsKey(e1)){
                   if(!Adjust1_temp.containsKey(e2)){
                       Adjust1_temp.put(e1,1);
                   }
               }

            }
            fileReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return Adjust1_temp;
    }
    public LinkedList CreateLink(String filename){
       LinkedList Link_temp=new LinkedList();
        HashMap<ArrayList<Integer>,Integer> matrix=CreateMatrix(filename);
        /////////////////

        //////////////////
        ls=1;mx=0;
        Node first1[];
        first=new Node[n];
        first1=new Node[n];
        for(int i=0;i<n;i++) {
            DataItems data = new DataItems(i);
            Link_temp.insertNode(data);
          first[i]=Link_temp.head.getNextNode();
            first1[i]=Link_temp.head.getNextNode();
        }
        for(int i=0;i<n;i++){
            int k=i;
            for(int j=0;j<n;j++){
                ArrayList<Integer> e1=new ArrayList<Integer>();e1.add(0,i);e1.add(1,j);
                ArrayList<Integer> e2=new ArrayList<Integer>();e2.add(0,j);e2.add(1,i);
                if(matrix.containsKey(e1) || matrix.containsKey(e2)){
                    Node nxt=new Node();
                    DataItems dataItems=new DataItems(j);
                    nxt.setDataItems(dataItems);
                    first1[i].setNextNode(nxt);
                    first1[i]=first1[i].getNextNode();
                }
            }
        }
        return Link_temp;
    }
    public int Circle(int i,int j){
        int c=0;
        if(mx==1) {
            ArrayList<Integer> A1 = new ArrayList<Integer>();
            ArrayList<Integer> A2 = new ArrayList<Integer>();
            for (int i1 = 0; i1 < n; i1++) {
                ArrayList<Integer> e1=new ArrayList<Integer>();e1.add(0,i);e1.add(1,i1);
                ArrayList<Integer> e2=new ArrayList<Integer>();e2.add(0,i1);e2.add(1,i);
                if ((Adjust1.containsKey(e1) || Adjust1.containsKey(e2)) && i1 != j) {
                    A1.add(i1);
                }
            }
            for (int j1 = 0; j1 < n; j1++) {
                ArrayList<Integer> e1=new ArrayList<Integer>();e1.add(0,j);e1.add(1,j1);
                ArrayList<Integer> e2=new ArrayList<Integer>();e2.add(0,j1);e2.add(1,j);
                if ((Adjust1.containsKey(e1) || Adjust1.containsKey(e2)) && j1 != i) {
                    A2.add(j1);
                }
            }
            for (int k1 = 0; k1 < A1.size(); k1++) {
                for (int k2 = 0; k2 < A2.size(); k2++) {
                    if (A1.get(k1) == A2.get(k2)) {
                        c++;
                        break;
                    }
                }
            }
        }
        if(ls==1){
            ArrayList<Integer> A1 = new ArrayList<Integer>();
            ArrayList<Integer> A2 = new ArrayList<Integer>();
            Node t1=first[i];
            Node t2=first[j];
            while(t1!=null){
                if(t1.getDataItems().getValue()!=j)
                    A1.add(t1.getDataItems().getValue());
                t1=t1.getNextNode();
            }
            while(t2!=null){
                if(t2.getDataItems().getValue()!=i)
                    A2.add(t2.getDataItems().getValue());
                t2=t2.getNextNode();
            }
            //System.out.println(A1);
            //System.out.println(A2);
            for (int k1 = 0; k1 < A1.size(); k1++) {
                for (int k2 = 0; k2 < A2.size(); k2++) {
                    if (A1.get(k1) == A2.get(k2)) {
                        c++;
                        break;
                    }
                }
            }
        }
        return c;
    }
    public int Degree(int i){
        int c=0;
        if(mx==1) {
            for (int k = 0; k < n; k++) {
                ArrayList<Integer> e1=new ArrayList<Integer>();e1.add(0,i);e1.add(1,k);
                ArrayList<Integer> e2=new ArrayList<Integer>();e2.add(0,k);e2.add(1,i);
                if (Adjust1.containsKey(e1) || Adjust1.containsKey(e2))
                    c++;
            }
        }
        if(ls==1){
            Node t=first[i].getNextNode();
            while(t!=null){
                c++;
                t=t.getNextNode();
            }
        }
        return c;
    }
    public boolean HasUnchecked(ArrayList<String> checked){
        boolean f=false;
        for(int i=0;i<checked.size();i++){
            String m[]=checked.get(i).split("#");
            if(Integer.parseInt(m[1])==0){
                f=true ;
                break;
            }
        }
        return f;
    }
    public boolean Parted(){
        boolean part=false;
        if(mx==1){
            temp=new ArrayList<Integer>();
            ArrayList<String> checked=new ArrayList<String>();
            temp.add(0);
            for(int i=0;i<n;i++){
                ArrayList<Integer> e1=new ArrayList<Integer>();e1.add(0,0);e1.add(1,i);
                ArrayList<Integer> e2=new ArrayList<Integer>();e2.add(0,i);e2.add(1,0);
                if(Adjust1.containsKey(e1) || Adjust1.containsKey(e2)){
                    if(!temp.contains(i)) {
                        temp.add(i);
                        String string=i+"#"+0;
                        checked.add(string);
                    }
                }
            }
            boolean f=HasUnchecked(checked);
            while(f==true) {
                ///////////////////////////////////////
                for(int i=0;i<checked.size();i++) {
                    String m[] = checked.get(i).split("#");
                    if (Integer.parseInt(m[1]) == 0){
                        checked.remove(i);
                        checked.add(i,m[0]+"#"+1);
                        for (int ii = 0; ii < n; ii++) {
                            ArrayList<Integer> e1=new ArrayList<Integer>();e1.add(0,Integer.parseInt(m[0]));e1.add(1,ii);
                            ArrayList<Integer> e2=new ArrayList<Integer>();e2.add(0,ii);e2.add(1,Integer.parseInt(m[0]));
                            if (Adjust1.containsKey(e1) || Adjust1.containsKey(e2)) {
                                if (!temp.contains(ii)) {
                                    checked.add(ii+"#"+0);
                                    temp.add(ii);
                                }
                            }

                        }
                }
                }
                ///////////////////////////////////////
                f=HasUnchecked(checked);
            }
            temp1=new ArrayList<Integer>();
            for(int u=0;u<n;u++){
                if(!temp.contains(u))
                    temp1.add(u);
            }
            System.out.println("part1 :"+temp);
            System.out.println("part2 :"+temp1);

            if(temp1.size()>=1)
                part=true;
        }
        if(ls==1){
            temp=new ArrayList<Integer>();
            ArrayList<String> checked=new ArrayList<String>();
            temp.add(0);
            Node t=first[0].getNextNode();
            while(t!=null){
                if(!temp.contains(t.getDataItems().getValue())) {
                    temp.add(t.getDataItems().getValue());
                    checked.add(t.getDataItems().getValue() + "#" + 0);
                }
                t=t.getNextNode();
            }
            //System.out.println("checked "+checked);
            boolean f=HasUnchecked(checked);
            while(f==true) {
                for(int i=0;i<checked.size();i++) {
                    String m[] = checked.get(i).split("#");
                    if (Integer.parseInt(m[1]) == 0) {
                        checked.remove(i);
                        checked.add(i, m[0] + "#" + 1);
                        Node node = first[Integer.parseInt(m[0])].getNextNode();
                        while (node != null) {
                            if (!temp.contains(node.getDataItems().getValue())) {
                                checked.add(node.getDataItems().getValue() + "#" + 0);
                                temp.add(node.getDataItems().getValue());
                            }
                            node = node.getNextNode();
                        }
                    }
                }
                f=HasUnchecked(checked);
            }
             temp1=new ArrayList<Integer>();
            for(int u=0;u<n;u++){
                if(!temp.contains(u))
                    temp1.add(u);
            }


            System.out.println("part1 :"+temp);
            System.out.println("part2 :"+temp1);
            if(temp1.size()>=1) {
                part = true;

            }
        }

        return part;
    }
    public int min(int k1,int k2){
        int min=0;
        if(k1==0 || k2==0)
            min=0;
        else{
            if(k1>k2)
                min=k2;
            else
            {
                if(k2>=k1){
                    min=k1;
                }
            }
        }
        return min;
    }
    public static double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        BigDecimal bd = new BigDecimal(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }
    public void exe1() {
        HashMap<Integer,HashMap<ArrayList<Integer>,Double>> xScore=new HashMap<Integer,HashMap<ArrayList<Integer>,Double>>();
        if(mx==1){
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    ArrayList<Integer> e1x=new ArrayList<Integer>();e1x.add(0,i);e1x.add(1,j);
                    ArrayList<Integer> e2=new ArrayList<Integer>();e2.add(0,j);e2.add(1,i);
                    if (Adjust1.containsKey(e1x) || Adjust1.containsKey(e2) ) {
                        ArrayList<Integer> e1 = new ArrayList<Integer>();
                        e1.add(0, i);
                        e1.add(1, j);
                        double d = (Circle(i, j) + 1);
                        double min = min(Degree(i) - 1, Degree(j) - 1);
                        //System.out.print(d+"    "+min+"   ");
                        Double s=0.0;
                        if(min==0)
                            s=10000000000000000000.0;
                        else
                        s = d / min;
                        //System.out.println( s);
                        s = round(s, 8);
                        HashMap<ArrayList<Integer>,Double> x=new HashMap<ArrayList<Integer>,Double>();
                        x.put(e1, s);
                        xScore.put(xScore.size(), x);
                    }
                }
            }
           // System.out.println(Score);
        }
        ///////////////////////////////////
        if(ls==1){
            for(int i=0;i<n;i++){
                Node node=first[i].getNextNode();
                while(node!=null){
                    ArrayList<Integer> e1 = new ArrayList<Integer>();
                    e1.add(0, first[i].getDataItems().getValue());
                    e1.add(1, node.getDataItems().getValue());
                    double d = (Circle(first[i].getDataItems().getValue(), node.getDataItems().getValue()) + 1);
                    double min = min(Degree(first[i].getDataItems().getValue()) - 1, Degree(node.getDataItems().getValue()) - 1);
                    //System.out.print(d+"    "+min+"   ");
                    Double s=0.0;
                    if(min==0)
                        s=10000000000000000000.0;
                    else
                        s = d / min;
                    //System.out.println( s);
                    s = round(s, 8);
                    HashMap<ArrayList<Integer>,Double> x=new HashMap<ArrayList<Integer>,Double>();
                    x.put(e1, s);
                    xScore.put(xScore.size(),x);
                    node=node.getNextNode();
                }
            }
            //System.out.println(Score);
        }
        Score=xScore;
    }
    ///////////////////////////////
    public void bubbleSort(){
        //`ArrayList<Integer> k1=null;
        //ArrayList<Integer> k2=null;
        double v1=0;
        double v2=0;
        for(Map.Entry<Integer,HashMap<ArrayList<Integer>,Double>> entry1:Score.entrySet()){
            int i=entry1.getKey();
            for(Map.Entry<ArrayList<Integer>,Double> entry:  Score.get(i).entrySet()){
                //k1=entry.getKey();
                v1=entry.getValue();
            }
            for(Map.Entry<Integer,HashMap<ArrayList<Integer>,Double>> entry2:Score.entrySet()){
                int j=entry2.getKey();
                for(Map.Entry<ArrayList<Integer>,Double> entry:  Score.get(j).entrySet()){
                    //k2=entry.getKey();
                    v2=entry.getValue();
                }
                if(v2>v1){
                    HashMap<ArrayList<Integer>,Double> temp1=Score.get(i);
                    HashMap<ArrayList<Integer>,Double> temp2=Score.get(j);
                    //System.out.println(i +" and "+j+" must replae");
                    //tempx.remove(i);
                    //tempx.remove(j);
                    Score.put(i,temp2);
                    Score.put(j, temp1);
                }
            }
        }
    }
    public HashMap<Integer,HashMap<ArrayList<Integer>,Double>> bubbleSortN(HashMap<Integer,HashMap<ArrayList<Integer>,Double>> Score){

        if(Score.size()>0) {
            ArrayList<Integer> k1=null;
            ArrayList<Integer> k2=null;
            double v1=0;
            double v2=0;
            for(Map.Entry<Integer,HashMap<ArrayList<Integer>,Double>> entry1:Score.entrySet()){
                int i=entry1.getKey();
                for(Map.Entry<ArrayList<Integer>,Double> entry:  Score.get(i).entrySet()){
                    k1=entry.getKey();
                    v1=entry.getValue();
                }
                for(Map.Entry<Integer,HashMap<ArrayList<Integer>,Double>> entry2:Score.entrySet()){
                    int j=entry2.getKey();
                    for(Map.Entry<ArrayList<Integer>,Double> entry:  Score.get(j).entrySet()){
                        k2=entry.getKey();
                        v2=entry.getValue();
                    }
                    if(v2>v1){
                        HashMap<ArrayList<Integer>,Double> temp1=Score.get(i);
                        HashMap<ArrayList<Integer>,Double> temp2=Score.get(j);
                        //System.out.println(i +" and "+j+" must replae");
                        //tempx.remove(i);
                        //tempx.remove(j);
                        Score.put(i,temp2);
                        Score.put(j, temp1);
                    }
                }
            }
        }
        return Score;
    }
    public void quickSort() {

        if (Score == null || Score.size() == 0) {
            return;
        }
        length=Score.size();
        quickSort1(0, length - 1);
    }
    private void quickSort1(int lowerIndex, int higherIndex) {
        int i = lowerIndex;
        int j = higherIndex;
        double pivot=0;
        HashMap<ArrayList<Integer>,Double> x=Score.get(lowerIndex+(higherIndex-lowerIndex)/2);
        for(Map.Entry<ArrayList<Integer>,Double> entry:x.entrySet()){
            pivot=entry.getValue();
        }
        while (i <= j) {
            //////////
            double a1=0;
            double a2=0;
            HashMap<ArrayList<Integer>,Double> x1=Score.get(i);
            for(Map.Entry<ArrayList<Integer>,Double> entry:x1.entrySet()){
                a1=entry.getValue();
            }
            HashMap<ArrayList<Integer>,Double> x2=Score.get(j);
            for(Map.Entry<ArrayList<Integer>,Double> entry:x2.entrySet()){
                a2=entry.getValue();
            }
            //////////
            while (a1 < pivot) {
                i++;
                x1=Score.get(i);
                for(Map.Entry<ArrayList<Integer>,Double> entry:x1.entrySet()){
                    a1=entry.getValue();
                }
            }
            while (a2 > pivot) {
                j--;
                x2=Score.get(j);
                for(Map.Entry<ArrayList<Integer>,Double> entry:x2.entrySet()){
                    a2=entry.getValue();
                }
            }
            if (i <= j) {
                exchangeNumbers(i, j);
                i++;
                j--;
            }
        }
        if (lowerIndex < j)
            quickSort1(lowerIndex, j);
        if (i < higherIndex)
            quickSort1(i, higherIndex);
    }
    private void quickSort1N1(int lowerIndex, int higherIndex) {
        if (higherIndex - lowerIndex + 1 <= N1) {
            HashMap<Integer, HashMap<ArrayList<Integer>, Double>> tmp = new HashMap<Integer, HashMap<ArrayList<Integer>, Double>>();
            for (Map.Entry<Integer, HashMap<ArrayList<Integer>, Double>> entry : Score.entrySet()) {
                int kv = entry.getKey();
                HashMap<ArrayList<Integer>, Double> vv = entry.getValue();
                if (kv >= lowerIndex && kv <= higherIndex) {
                    tmp.put(kv, vv);
                }
            }
            if(tmp.size()>0) {
                System.out.println(lowerIndex + "   " + higherIndex + "   " + tmp.size());
                tmp = bubbleSortN(tmp);
                for (Map.Entry<Integer, HashMap<ArrayList<Integer>, Double>> entry : tmp.entrySet()) {
                    int kv = entry.getKey();
                    HashMap<ArrayList<Integer>, Double> vv = entry.getValue();
                    Score.put(kv, vv);
                }
            }
        }
        else {
            int i = lowerIndex;
            int j = higherIndex;
            double pivot = 0;
            HashMap<ArrayList<Integer>, Double> x = Score.get(lowerIndex + (higherIndex - lowerIndex) / 2);
            for (Map.Entry<ArrayList<Integer>, Double> entry : x.entrySet()) {
                pivot = entry.getValue();
            }
            while (i <= j) {
                //////////
                double a1 = 0;
                double a2 = 0;
                HashMap<ArrayList<Integer>, Double> x1 = Score.get(i);
                for (Map.Entry<ArrayList<Integer>, Double> entry : x1.entrySet()) {
                    a1 = entry.getValue();
                }
                HashMap<ArrayList<Integer>, Double> x2 = Score.get(j);
                for (Map.Entry<ArrayList<Integer>, Double> entry : x2.entrySet()) {
                    a2 = entry.getValue();
                }
                //////////
                while (a1 < pivot) {
                    i++;
                    x1 = Score.get(i);
                    for (Map.Entry<ArrayList<Integer>, Double> entry : x1.entrySet()) {
                        a1 = entry.getValue();
                    }
                }
                while (a2 > pivot) {
                    j--;
                    x2 = Score.get(j);
                    for (Map.Entry<ArrayList<Integer>, Double> entry : x2.entrySet()) {
                        a2 = entry.getValue();
                    }
                }
                if (i <= j) {
                    exchangeNumbers(i, j);
                    //move index to next position on both sides
                    i++;
                    j--;
                }
            }
            // call quickSort() method recursively
            if (lowerIndex < j)
                quickSort1N1(lowerIndex, j);
            if (i < higherIndex)
                quickSort1N1(i, higherIndex);
        }
    }
    public void quickSortN1() {
        if (Score == null || Score.size() == 0) {
            return;
        }
        length=Score.size();
        quickSort1N1(0, length - 1);
    }
    private void quickSort1N2(int lowerIndex, int higherIndex) {
        if (higherIndex - lowerIndex + 1 <= N1) {
            HashMap<Integer, HashMap<ArrayList<Integer>, Double>> tmp = new HashMap<Integer, HashMap<ArrayList<Integer>, Double>>();
            for (Map.Entry<Integer, HashMap<ArrayList<Integer>, Double>> entry : Score.entrySet()) {
                int kv = entry.getKey();
                HashMap<ArrayList<Integer>, Double> vv = entry.getValue();
                if (kv >= lowerIndex && kv <= higherIndex) {
                    tmp.put(kv, vv);
                }
            }
            if(tmp.size()>0) {
                tmp = insertionSortN(tmp);
                for (Map.Entry<Integer, HashMap<ArrayList<Integer>, Double>> entry : tmp.entrySet()) {
                    int kv = entry.getKey();
                    HashMap<ArrayList<Integer>, Double> vv = entry.getValue();
                    Score.put(kv, vv);
                }
            }
        }
        else {
            int i = lowerIndex;
            int j = higherIndex;
            double pivot = 0;
            HashMap<ArrayList<Integer>, Double> x = Score.get(lowerIndex + (higherIndex - lowerIndex) / 2);
            for (Map.Entry<ArrayList<Integer>, Double> entry : x.entrySet()) {
                pivot = entry.getValue();
            }
            while (i <= j) {
                //////////
                double a1 = 0;
                double a2 = 0;
                HashMap<ArrayList<Integer>, Double> x1 = Score.get(i);
                for (Map.Entry<ArrayList<Integer>, Double> entry : x1.entrySet()) {
                    a1 = entry.getValue();
                }
                HashMap<ArrayList<Integer>, Double> x2 = Score.get(j);
                for (Map.Entry<ArrayList<Integer>, Double> entry : x2.entrySet()) {
                    a2 = entry.getValue();
                }
                //////////
                while (a1 < pivot) {
                    i++;
                    x1 = Score.get(i);
                    for (Map.Entry<ArrayList<Integer>, Double> entry : x1.entrySet()) {
                        a1 = entry.getValue();
                    }
                }
                while (a2 > pivot) {
                    j--;
                    x2 = Score.get(j);
                    for (Map.Entry<ArrayList<Integer>, Double> entry : x2.entrySet()) {
                        a2 = entry.getValue();
                    }
                }
                if (i <= j) {
                    exchangeNumbers(i, j);
                    //move index to next position on both sides
                    i++;
                    j--;
                }
            }
            // call quickSort() method recursively
            if (lowerIndex < j)
                quickSort1N1(lowerIndex, j);
            if (i < higherIndex)
                quickSort1N1(i, higherIndex);
        }
    }
    public void quickSortN2() {
        if (Score == null || Score.size() == 0) {
            return;
        }
        length=Score.size();
        quickSort1N2(0, length - 1);
    }
    private void exchangeNumbers(int i, int j) {
        HashMap<ArrayList<Integer>,Double> temp = Score.get(i);
        Score.put(i,Score.get(j));
        Score.put(j,temp);
    }
    public  void insertionSort() {
        int n = Score.size();
        for(Map.Entry<Integer,HashMap<ArrayList<Integer>,Double>> entry1:Score.entrySet()){
            int i=entry1.getKey();
            HashMap<ArrayList<Integer>,Double> temp=new HashMap<ArrayList<Integer>,Double>();
            temp=Score.get(i);
            double key=0;
            for(Map.Entry<ArrayList<Integer>,Double> entry:temp.entrySet()){
                key=entry.getValue();
            }
            if(i-1>=0){
            int j = i-1;

            HashMap<ArrayList<Integer>,Double> tempx=new HashMap<ArrayList<Integer>,Double>();
            tempx=Score.get(j);
                double keyx=0;
            for(Map.Entry<ArrayList<Integer>,Double> entry:tempx.entrySet()){
                keyx=entry.getValue();
            }
            while (j>=0 && keyx > key)
            {
                Score.put(j+1,Score.get(j));
                j = j-1;
            }
            Score.put(j+1,Score.get(i));}
        }
    }
    public  HashMap<Integer,HashMap<ArrayList<Integer>,Double>> insertionSortN(HashMap<Integer,HashMap<ArrayList<Integer>,Double>> Score) {

        int n = Score.size();
        for(Map.Entry<Integer,HashMap<ArrayList<Integer>,Double>> entry1:Score.entrySet()){
            int i=entry1.getKey();
            HashMap<ArrayList<Integer>,Double> temp=new HashMap<ArrayList<Integer>,Double>();
            temp=Score.get(i);double key=0;
            for(Map.Entry<ArrayList<Integer>,Double> entry:temp.entrySet()){
                key=entry.getValue();
            }
            int j = i-1;

            HashMap<ArrayList<Integer>,Double> tempx=new HashMap<ArrayList<Integer>,Double>();
            tempx=Score.get(j);double keyx=0;
            for(Map.Entry<ArrayList<Integer>,Double> entry:tempx.entrySet()){
                keyx=entry.getValue();
            }
            while (j>=0 && keyx > key)
            {
                Score.put(j+1,Score.get(j));
                j = j-1;
            }
            Score.put(j+1,Score.get(i));
        }
        return Score;
    }
    private void mergeSort(int lowerIndex, int higherIndex) {
        if (lowerIndex < higherIndex) {
            int middle = lowerIndex + (higherIndex - lowerIndex) / 2;

            mergeSort(lowerIndex, middle);

            mergeSort(middle + 1, higherIndex);

            mergeParts(lowerIndex, middle, higherIndex);
        }
    }
    private void mergeParts(int lowerIndex, int middle, int higherIndex) {
        for (int i = lowerIndex; i <= higherIndex; i++) {
            TempScore.put(i,Score.get(i));
        }
        int i = lowerIndex;
        int j = middle + 1;
        int k = lowerIndex;
        while (i <= middle && j <= higherIndex) {
            HashMap<ArrayList<Integer>,Double> t1=new HashMap<ArrayList<Integer>,Double>();
            t1=TempScore.get(i);double a1=0;
            for(Map.Entry<ArrayList<Integer>,Double> entry:t1.entrySet()){
                a1=entry.getValue();
            }
            HashMap<ArrayList<Integer>,Double> t2=new HashMap<ArrayList<Integer>,Double>();
            t2=TempScore.get(j);double a2=0;
            for(Map.Entry<ArrayList<Integer>,Double> entry:t2.entrySet()){
                a2=entry.getValue();
            }
            if (a1 <= a2) {
                Score.put(k,TempScore.get(i));
                i++;
                t1=TempScore.get(i);
                for(Map.Entry<ArrayList<Integer>,Double> entry:t1.entrySet()){
                    a1=entry.getValue();
                }
                t2=TempScore.get(j);
                for(Map.Entry<ArrayList<Integer>,Double> entry:t2.entrySet()){
                    a2=entry.getValue();
                }
            } else {
                Score.put(k,TempScore.get(j));
                j++;
            }
            k++;
        }
        while (i <= middle) {
            Score.put(k,TempScore.get(i));
            k++;
            i++;
        }
    }
    public void Write(){

        PrintWriter writer = null;
        try {
            writer = new PrintWriter("c:\\users\\mahnoosh\\desktop\\N\\G.txt");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        writer.println(temp);
        writer.println("...............................");
        writer.println(temp1);
        writer.close();
    }
    public void exe2(int selector,int Nm) {
        /////////////
        if (selector==0){
            boolean f = Parted();int cnt=0;
            while (f == false) {
            //while(cnt<=40){
                exe1();
                bubbleSort();
                //System.out.println(Score);
                System.out.println(Score.size()+"itration "+cnt+"  parted "+f);
                HashMap<ArrayList<Integer>,Double> temp1=Score.get(0);
                for(Map.Entry<ArrayList<Integer>,Double> entry:temp1.entrySet()){
                    ArrayList<Integer> k1=entry.getKey();
                    ArrayList<Integer> e1=new ArrayList<Integer>();
                    e1.add(0,k1.get(0));
                    e1.add(1,k1.get(1));
                    ArrayList<Integer> e2=new ArrayList<Integer>();
                    e2.add(0,k1.get(1));
                    e2.add(1,k1.get(0));
                    if(Adjust1.containsKey(e1))
                    {
                        Adjust1.remove(e1);
                    }
                    if(Adjust1.containsKey(e2))
                    {
                        Adjust1.remove(e2);
                    }
                    System.out.println("Adjust1["+k1.get(0)+"]["+k1.get(1)+"]=0");
                    System.out.println("Adjust1["+k1.get(1)+"]["+k1.get(0)+"]=0");
                }
                System.out.println("parts are as below");
                f = Parted();
                if(f==true){
                    Write();
                }
                System.out.println("------------------------------------");
                cnt++;
            }
        }
        if(selector==1){
            boolean f = Parted();
            int cnt=0;
                while (f == false) {
               // while(cnt<1){
                    exe1();
                    bubbleSort();
                    //System.out.println(Score);
                System.out.println(Score.size()+"itration "+cnt+"  parted "+f);
                HashMap<ArrayList<Integer>,Double> temp1=Score.get(0);
                for(Map.Entry<ArrayList<Integer>,Double> entry:temp1.entrySet()){
                    ArrayList<Integer> k1=entry.getKey();
                    System.out.println(k1.get(0)+"   "+k1.get(1));
                    Node t1=first[k1.get(0)];
                    while (t1.getNextNode()!=null){
                        if(t1.getNextNode().getDataItems().getValue()==k1.get(1)){
                            if(t1.getNextNode().getNextNode()!=null){

                                t1.setNextNode(t1.getNextNode().getNextNode());
                            }
                            else{
                                t1.setNextNode(null);
                            }
                            break;
                        }
                        t1=t1.getNextNode();
                    }
                    Node t2=first[k1.get(1)];
                    while (t2.getNextNode()!=null){
                        if(t2.getNextNode().getDataItems().getValue()==k1.get(0)){
                            if(t2.getNextNode().getNextNode()!=null){
                                t2.setNextNode(t2.getNextNode().getNextNode());
                            }
                            else{
                                t2.setNextNode(null);
                            }
                            break;
                        }
                        t2=t2.getNextNode();
                    }
                }
                for(int p=0;p<n;p++){
                    Node t=first[p];
                    while(t!=null){
                        System.out.print(t.getDataItems().getValue()+"    ");
                        t=t.getNextNode();
                    }
                    System.out.println();
                }
                System.out.println("parts are as below");
                f = Parted();
                    if(f==true){
                        Write();
                    }
                System.out.println("------------------------------------");
                cnt++;
                }
            }
            if (selector==2){
                boolean f = Parted();int cnt=0;
                while (f == false) {
                    //while(cnt<=40){
                    exe1();
                    quickSort();
                    System.out.println(Score.size()+"itration "+cnt+"  parted "+f);
                    HashMap<ArrayList<Integer>,Double> temp1=Score.get(0);
                    for(Map.Entry<ArrayList<Integer>,Double> entry:temp1.entrySet()){
                        ArrayList<Integer> k1=entry.getKey();
                        ArrayList<Integer> e1=new ArrayList<Integer>();
                        e1.add(0,k1.get(0));
                        e1.add(1,k1.get(1));
                        ArrayList<Integer> e2=new ArrayList<Integer>();
                        e2.add(0,k1.get(1));
                        e2.add(1,k1.get(0));
                        if(Adjust1.containsKey(e1))
                        {
                            Adjust1.remove(e1);
                        }
                        if(Adjust1.containsKey(e2))
                        {
                            Adjust1.remove(e2);
                        }
                        System.out.println("Adjust1["+k1.get(0)+"]["+k1.get(1)+"]=0");
                        System.out.println("Adjust1["+k1.get(1)+"]["+k1.get(0)+"]=0");
                    }
                    System.out.println("parts are as below");
                    f = Parted();
                    if(f==true){
                        Write();
                    }
                    System.out.println("------------------------------------");
                    cnt++;
                }
            }
        if(selector==3){
            boolean f = Parted();
            int cnt=0;
            while (f == false) {
                // while(cnt<1){
                exe1();
                quickSort();
                //System.out.println(Score);
                System.out.println(Score.size()+"itration "+cnt+"  parted "+f);
                HashMap<ArrayList<Integer>,Double> temp1=Score.get(0);
                for(Map.Entry<ArrayList<Integer>,Double> entry:temp1.entrySet()){
                    ArrayList<Integer> k1=entry.getKey();
                    System.out.println(k1.get(0)+"   "+k1.get(1));
                    Node t1=first[k1.get(0)];
                    while (t1.getNextNode()!=null){
                        if(t1.getNextNode().getDataItems().getValue()==k1.get(1)){
                            if(t1.getNextNode().getNextNode()!=null){

                                t1.setNextNode(t1.getNextNode().getNextNode());
                            }
                            else{
                                t1.setNextNode(null);
                            }
                            break;
                        }
                        t1=t1.getNextNode();
                    }
                    Node t2=first[k1.get(1)];
                    while (t2.getNextNode()!=null){
                        if(t2.getNextNode().getDataItems().getValue()==k1.get(0)){
                            if(t2.getNextNode().getNextNode()!=null){
                                t2.setNextNode(t2.getNextNode().getNextNode());
                            }
                            else{
                                t2.setNextNode(null);
                            }
                            break;
                        }
                        t2=t2.getNextNode();
                    }
                }
                for(int p=0;p<n;p++){
                    Node t=first[p];
                    while(t!=null){
                        System.out.print(t.getDataItems().getValue()+"    ");
                        t=t.getNextNode();
                    }
                    System.out.println();
                }
                System.out.println("parts are as below");
                f = Parted();
                if(f==true){
                    Write();
                }
                System.out.println("------------------------------------");
                cnt++;
            }
        }
        if (selector==4){
            boolean f = Parted();int cnt=0;
            while (f == false) {
                //while(cnt<=40){
                exe1();
                insertionSort();
                System.out.println(Score.size()+"itration "+cnt+"  parted "+f);
                HashMap<ArrayList<Integer>,Double> temp1=Score.get(0);
                for(Map.Entry<ArrayList<Integer>,Double> entry:temp1.entrySet()){
                    ArrayList<Integer> k1=entry.getKey();
                    ArrayList<Integer> e1=new ArrayList<Integer>();
                    e1.add(0,k1.get(0));
                    e1.add(1,k1.get(1));
                    ArrayList<Integer> e2=new ArrayList<Integer>();
                    e2.add(0,k1.get(1));
                    e2.add(1,k1.get(0));
                    if(Adjust1.containsKey(e1))
                    {
                        Adjust1.remove(e1);
                    }
                    if(Adjust1.containsKey(e2))
                    {
                        Adjust1.remove(e2);
                    }
                    System.out.println("Adjust1["+k1.get(0)+"]["+k1.get(1)+"]=0");
                    System.out.println("Adjust1["+k1.get(1)+"]["+k1.get(0)+"]=0");
                }
                System.out.println("parts are as below");
                f = Parted();
                if(f==true){
                    Write();
                }
                System.out.println("------------------------------------");
                cnt++;
            }
        }
        if(selector==5){
            boolean f = Parted();
            int cnt=0;
            while (f == false) {
                // while(cnt<1){
                exe1();
                insertionSort();
                //System.out.println(Score);
                System.out.println(Score.size()+"itration "+cnt+"  parted "+f);
                HashMap<ArrayList<Integer>,Double> temp1=Score.get(0);
                for(Map.Entry<ArrayList<Integer>,Double> entry:temp1.entrySet()){
                    ArrayList<Integer> k1=entry.getKey();
                    System.out.println(k1.get(0)+"   "+k1.get(1));
                    Node t1=first[k1.get(0)];
                    while (t1.getNextNode()!=null){
                        if(t1.getNextNode().getDataItems().getValue()==k1.get(1)){
                            if(t1.getNextNode().getNextNode()!=null){

                                t1.setNextNode(t1.getNextNode().getNextNode());
                            }
                            else{
                                t1.setNextNode(null);
                            }
                            break;
                        }
                        t1=t1.getNextNode();
                    }
                    Node t2=first[k1.get(1)];
                    while (t2.getNextNode()!=null){
                        if(t2.getNextNode().getDataItems().getValue()==k1.get(0)){
                            if(t2.getNextNode().getNextNode()!=null){
                                t2.setNextNode(t2.getNextNode().getNextNode());
                            }
                            else{
                                t2.setNextNode(null);
                            }
                            break;
                        }
                        t2=t2.getNextNode();
                    }
                }
                for(int p=0;p<n;p++){
                    Node t=first[p];
                    while(t!=null){
                        System.out.print(t.getDataItems().getValue()+"    ");
                        t=t.getNextNode();
                    }
                    System.out.println();
                }
                System.out.println("parts are as below");
                f = Parted();
                if(f==true){
                    Write();
                }
                System.out.println("------------------------------------");
                cnt++;
            }
        }
        if (selector==6){
            boolean f = Parted();int cnt=0;
            while (f == false) {
                //while(cnt<=40){
                exe1();
                TempScore=new HashMap<Integer,HashMap<ArrayList<Integer>,Double>>();
                mergeSort(0,Score.size()-1);
                System.out.println(Score.size()+"itration "+cnt+"  parted "+f);
                HashMap<ArrayList<Integer>,Double> temp1=Score.get(0);
                for(Map.Entry<ArrayList<Integer>,Double> entry:temp1.entrySet()){
                    ArrayList<Integer> k1=entry.getKey();
                    ArrayList<Integer> e1=new ArrayList<Integer>();
                    e1.add(0,k1.get(0));
                    e1.add(1,k1.get(1));
                    ArrayList<Integer> e2=new ArrayList<Integer>();
                    e2.add(0,k1.get(1));
                    e2.add(1,k1.get(0));
                    if(Adjust1.containsKey(e1))
                    {
                        Adjust1.remove(e1);
                    }
                    if(Adjust1.containsKey(e2))
                    {
                        Adjust1.remove(e2);
                    }
                    System.out.println("Adjust1["+k1.get(0)+"]["+k1.get(1)+"]=0");
                    System.out.println("Adjust1["+k1.get(1)+"]["+k1.get(0)+"]=0");
                }
                System.out.println("parts are as below");
                f = Parted();
                if(f==true){
                    Write();
                }
                System.out.println("------------------------------------");
                cnt++;
            }
        }
        if(selector==7){
            boolean f = Parted();
            int cnt=0;
            while (f == false) {
                // while(cnt<1){
                exe1();
                TempScore=new HashMap<Integer,HashMap<ArrayList<Integer>,Double>>();
                mergeSort(0,Score.size()-1);
                //System.out.println(Score);
                System.out.println(Score.size() + "itration "+cnt+"  parted "+f);
                HashMap<ArrayList<Integer>,Double> temp1=Score.get(0);
                for(Map.Entry<ArrayList<Integer>,Double> entry:temp1.entrySet()){
                    ArrayList<Integer> k1=entry.getKey();
                    System.out.println(k1.get(0)+"   "+k1.get(1));
                    Node t1=first[k1.get(0)];
                    while (t1.getNextNode()!=null){
                        if(t1.getNextNode().getDataItems().getValue()==k1.get(1)){
                            if(t1.getNextNode().getNextNode()!=null){

                                t1.setNextNode(t1.getNextNode().getNextNode());
                            }
                            else{
                                t1.setNextNode(null);
                            }
                            break;
                        }
                        t1=t1.getNextNode();
                    }
                    Node t2=first[k1.get(1)];
                    while (t2.getNextNode()!=null){
                        if(t2.getNextNode().getDataItems().getValue()==k1.get(0)){
                            if(t2.getNextNode().getNextNode()!=null){
                                t2.setNextNode(t2.getNextNode().getNextNode());
                            }
                            else{
                                t2.setNextNode(null);
                            }
                            break;
                        }
                        t2=t2.getNextNode();
                    }
                }
                for(int p=0;p<n;p++){
                    Node t=first[p];
                    while(t!=null){
                        System.out.print(t.getDataItems().getValue()+"    ");
                        t=t.getNextNode();
                    }
                    System.out.println();
                }
                System.out.println("parts are as below");
                f = Parted();
                if(f==true){
                    Write();
                }
                System.out.println("------------------------------------");
                cnt++;
            }
        }
        if (selector==8){
            N1=Nm;
            boolean f = Parted();int cnt=0;
            while (f == false) {
                //while(cnt<=40){
                exe1();
                quickSortN1();
                System.out.println(Score.size() + "itration " + cnt + "  parted " + f);
                HashMap<ArrayList<Integer>,Double> temp1=Score.get(0);
                for(Map.Entry<ArrayList<Integer>,Double> entry:temp1.entrySet()){
                    ArrayList<Integer> k1=entry.getKey();
                    ArrayList<Integer> e1=new ArrayList<Integer>();
                    e1.add(0,k1.get(0));
                    e1.add(1,k1.get(1));
                    ArrayList<Integer> e2=new ArrayList<Integer>();
                    e2.add(0,k1.get(1));
                    e2.add(1,k1.get(0));
                    if(Adjust1.containsKey(e1))
                    {
                        Adjust1.remove(e1);
                    }
                    if(Adjust1.containsKey(e2))
                    {
                        Adjust1.remove(e2);
                    }
                    System.out.println("Adjust1["+k1.get(0)+"]["+k1.get(1)+"]=0");
                    System.out.println("Adjust1["+k1.get(1)+"]["+k1.get(0)+"]=0");
                }
                System.out.println("parts are as below");
                f = Parted();
                if(f==true){
                    Write();
                }
                System.out.println("------------------------------------");
                cnt++;
            }
        }
        if(selector==9){
            boolean f = Parted();
            int cnt=0;
            while (f == false) {
                // while(cnt<1){
                exe1();
                quickSortN1();
                //System.out.println(Score);
                System.out.println(Score.size() + "itration "+cnt+"  parted "+f);
                HashMap<ArrayList<Integer>,Double> temp1=Score.get(0);
                for(Map.Entry<ArrayList<Integer>,Double> entry:temp1.entrySet()){
                    ArrayList<Integer> k1=entry.getKey();
                    System.out.println(k1.get(0)+"   "+k1.get(1));
                    Node t1=first[k1.get(0)];
                    while (t1.getNextNode()!=null){
                        if(t1.getNextNode().getDataItems().getValue()==k1.get(1)){
                            if(t1.getNextNode().getNextNode()!=null){

                                t1.setNextNode(t1.getNextNode().getNextNode());
                            }
                            else{
                                t1.setNextNode(null);
                            }
                            break;
                        }
                        t1=t1.getNextNode();
                    }
                    Node t2=first[k1.get(1)];
                    while (t2.getNextNode()!=null){
                        if(t2.getNextNode().getDataItems().getValue()==k1.get(0)){
                            if(t2.getNextNode().getNextNode()!=null){
                                t2.setNextNode(t2.getNextNode().getNextNode());
                            }
                            else{
                                t2.setNextNode(null);
                            }
                            break;
                        }
                        t2=t2.getNextNode();
                    }
                }
                for(int p=0;p<n;p++){
                    Node t=first[p];
                    while(t!=null){
                        System.out.print(t.getDataItems().getValue()+"    ");
                        t=t.getNextNode();
                    }
                    System.out.println();
                }
                System.out.println("parts are as below");
                f = Parted();
                if(f==true){
                    Write();
                }
                System.out.println("------------------------------------");
                cnt++;
            }
        }
        if (selector==10){
            N1=Nm;
            boolean f = Parted();int cnt=0;
            while (f == false) {
                //while(cnt<=40){
                exe1();
                quickSortN2();
                System.out.println(Score.size() + "itration " + cnt + "  parted " + f);
                HashMap<ArrayList<Integer>,Double> temp1=Score.get(0);
                for(Map.Entry<ArrayList<Integer>,Double> entry:temp1.entrySet()){
                    ArrayList<Integer> k1=entry.getKey();
                    ArrayList<Integer> e1=new ArrayList<Integer>();
                    e1.add(0,k1.get(0));
                    e1.add(1,k1.get(1));
                    ArrayList<Integer> e2=new ArrayList<Integer>();
                    e2.add(0,k1.get(1));
                    e2.add(1,k1.get(0));
                    if(Adjust1.containsKey(e1))
                    {
                        Adjust1.remove(e1);
                    }
                    if(Adjust1.containsKey(e2))
                    {
                        Adjust1.remove(e2);
                    }
                    System.out.println("Adjust1["+k1.get(0)+"]["+k1.get(1)+"]=0");
                    System.out.println("Adjust1["+k1.get(1)+"]["+k1.get(0)+"]=0");
                }
                System.out.println("parts are as below");
                f = Parted();
                if(f==true){
                    Write();
                }
                System.out.println("------------------------------------");
                cnt++;
            }
        }
        if(selector==11){
            boolean f = Parted();
            int cnt=0;
            while (f == false) {
                // while(cnt<1){
                exe1();
                quickSortN2();
                //System.out.println(Score);
                System.out.println(Score.size() + "itration "+cnt+"  parted "+f);
                HashMap<ArrayList<Integer>,Double> temp1=Score.get(0);
                for(Map.Entry<ArrayList<Integer>,Double> entry:temp1.entrySet()){
                    ArrayList<Integer> k1=entry.getKey();
                    System.out.println(k1.get(0)+"   "+k1.get(1));
                    Node t1=first[k1.get(0)];
                    while (t1.getNextNode()!=null){
                        if(t1.getNextNode().getDataItems().getValue()==k1.get(1)){
                            if(t1.getNextNode().getNextNode()!=null){

                                t1.setNextNode(t1.getNextNode().getNextNode());
                            }
                            else{
                                t1.setNextNode(null);
                            }
                            break;
                        }
                        t1=t1.getNextNode();
                    }
                    Node t2=first[k1.get(1)];
                    while (t2.getNextNode()!=null){
                        if(t2.getNextNode().getDataItems().getValue()==k1.get(0)){
                            if(t2.getNextNode().getNextNode()!=null){
                                t2.setNextNode(t2.getNextNode().getNextNode());
                            }
                            else{
                                t2.setNextNode(null);
                            }
                            break;
                        }
                        t2=t2.getNextNode();
                    }
                }
                for(int p=0;p<n;p++){
                    Node t=first[p];
                    while(t!=null){
                        System.out.print(t.getDataItems().getValue()+"    ");
                        t=t.getNextNode();
                    }
                    System.out.println();
                }
                System.out.println("parts are as below");
                f = Parted();
                if(f==true){
                    Write();
                }
                System.out.println("------------------------------------");
                cnt++;
            }
        }
        }
        /////////////////////////
    }

//}
