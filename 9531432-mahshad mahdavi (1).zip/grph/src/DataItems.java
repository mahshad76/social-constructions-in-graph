
public class DataItems{


    private int  value;

    public DataItems(int _value){
        this.value=_value;
    }

    public int getValue() {
        return value;
    }

}
