import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;
public class main {
    public static void main(String args[]) {

        System.out.println("choose:");
        System.out.println("run matrix bubble(0)");
        System.out.println("run link bubble(1)");
        System.out.println("run matrix quick(2)");
        System.out.println("run link quick(3)");
        System.out.println("run matrix insertion(4)");
        System.out.println("run link insertion(5)");
        System.out.println("run matrix merg(6)");
        System.out.println("run link merg(7)");
        System.out.println("run matrix optimum bubble n(8)");
        System.out.println("run link optimum bubble n(9)");
        System.out.println("run matrix optimum insertion n(10)");
        System.out.println("run link optimum insertion n(11)");
        Scanner scanner = new Scanner(System.in);
        int selector = scanner.nextInt();
        if (selector == 0) {
            MatrixGraph graph0 = new MatrixGraph();
            graph0.Adjust1 = graph0.CreateMatrix("C:\\Users\\mahnoosh\\Desktop\\N\\g1.txt");
            graph0.exe2(selector,0);
            //System.out.println(graph0.Adjust1);
            System.out.println("end");

        }
        if (selector == 1) {
            MatrixGraph graph1 = new MatrixGraph();
            graph1.Adjust2 = graph1.CreateLink("C:\\Users\\mahnoosh\\Desktop\\N\\g1.txt");
            graph1.exe2(selector,0);

        }
        if (selector == 2) {
            MatrixGraph graph2 = new MatrixGraph();
            graph2.Adjust1 = graph2.CreateMatrix("C:\\Users\\mahnoosh\\Desktop\\N\\g1.txt");
            graph2.exe2(selector,0);
            //System.out.println(graph2.Adjust1);
            System.out.println("end");
        }
        if (selector == 3) {
            MatrixGraph graph3 = new MatrixGraph();
            graph3.Adjust2 = graph3.CreateLink("C:\\Users\\mahnoosh\\Desktop\\N\\g1.txt");
            graph3.exe2(selector,0);

        }
        if (selector == 4) {
            MatrixGraph graph4 = new MatrixGraph();
            graph4.Adjust1 = graph4.CreateMatrix("C:\\Users\\mahnoosh\\Desktop\\N\\g1.txt");
            graph4.exe2(selector,0);
            //System.out.println(graph4.Adjust1);
            //System.out.println("end");
        }
        if (selector == 5) {
            MatrixGraph graph5 = new MatrixGraph();
            graph5.Adjust2 = graph5.CreateLink("C:\\Users\\mahnoosh\\Desktop\\N\\test1.txt");
            graph5.exe2(selector,0);
            //System.out.println("end");

        }
        if (selector == 6) {
            MatrixGraph graph6 = new MatrixGraph();
            graph6.Adjust1 = graph6.CreateMatrix("C:\\Users\\mahnoosh\\Desktop\\N\\test1.txt");
            graph6.exe2(selector,0);
            System.out.println(graph6.Adjust1);
            System.out.println("end");
        }
        if (selector == 7) {
            MatrixGraph graph7 = new MatrixGraph();
            graph7.Adjust2 = graph7.CreateLink("C:\\Users\\mahnoosh\\Desktop\\N\\test1.txt");
            graph7.exe2(selector,0);

        }
        if (selector == 8) {
            System.out.println("Enter N");
            Scanner scanner1 = new Scanner(System.in);
            int nx = scanner1.nextInt();
            MatrixGraph graph0 = new MatrixGraph();
            graph0.Adjust1 = graph0.CreateMatrix("C:\\Users\\mahnoosh\\Desktop\\N\\test1.txt");
            graph0.exe2(selector,nx);
           // System.out.println(graph0.Adjust1);
            //System.out.println("end");
        }
        if (selector == 9) {
            System.out.println("Enter N");
            Scanner scanner1 = new Scanner(System.in);
            int nx = scanner1.nextInt();
            MatrixGraph graph1 = new MatrixGraph();
            graph1.Adjust2 = graph1.CreateLink("C:\\Users\\mahnoosh\\Desktop\\N\\test1.txt");
            graph1.exe2(selector,nx);

        }
        if (selector == 10) {
            System.out.println("Enter N");
            Scanner scanner1 = new Scanner(System.in);
            int nx = scanner1.nextInt();
            MatrixGraph graph0 = new MatrixGraph();
            graph0.Adjust1 = graph0.CreateMatrix("C:\\Users\\mahnoosh\\Desktop\\N\\test1.txt");
            graph0.exe2(selector,nx);
            //System.out.println(graph0.Adjust1);
            //System.out.println("end");
        }
        if (selector == 11) {
            System.out.println("Enter N");
            Scanner scanner1 = new Scanner(System.in);
            int nx = scanner1.nextInt();
            MatrixGraph graph1 = new MatrixGraph();
            graph1.Adjust2 = graph1.CreateLink("C:\\Users\\mahnoosh\\Desktop\\N\\test1.txt");
            graph1.exe2(selector,nx);

        }
    }
}
