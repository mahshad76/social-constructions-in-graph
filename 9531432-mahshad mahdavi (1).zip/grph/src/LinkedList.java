

public class LinkedList{

    HeadNode head;

    public LinkedList(){
        head = new HeadNode();
    }


    public void insertNode(DataItems _data){
        Node newNode = new Node();
        newNode.setDataItems(_data);
        Node nextNode = head.getNextNode();
        head.setNextNode(newNode);
        newNode.setNextNode(nextNode);
    }
    


}
